import hashlib
import json
import time
import uuid
import os
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy.orm import joinedload

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24).hex()
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///blockchain.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db = SQLAlchemy(app)

# Database Models
class User(db.Model):
    id = db.Column(db.String(8), primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    role = db.Column(db.String(20), nullable=False)
    wallet_address = db.Column(db.String(64), nullable=False)
    password_hash = db.Column(db.String(64), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    products = db.relationship('Product', backref='farmer', lazy=True)
    transactions = db.relationship('Transaction', backref='actor', lazy=True)

    def __repr__(self):
        return f'<User {self.name}>'

class Product(db.Model):
    id = db.Column(db.String(8), primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    origin = db.Column(db.String(100), nullable=False)
    harvest_date = db.Column(db.String(10), nullable=False)
    initial_price = db.Column(db.Float, default=0.0)
    quality_metrics = db.Column(db.Text, nullable=False)
    current_owner_id = db.Column(db.String(8), db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    transactions = db.relationship('Transaction', backref='product', lazy=True)

    def __repr__(self):
        return f'<Product {self.name}>'

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.String(8), db.ForeignKey('product.id'), nullable=False)
    action = db.Column(db.String(20), nullable=False)
    actor_id = db.Column(db.String(8), db.ForeignKey('user.id'), nullable=False)
    details = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Transaction {self.action} for {self.product_id}>'
    
    def get_actor_name(self):
        """Safely get actor name without causing session issues"""
        try:
            with app.app_context():
                actor = User.query.get(self.actor_id)
                return actor.name if actor else f"User {self.actor_id}"
        except:
            return f"User {self.actor_id}"

class Block(db.Model):
    index = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    transactions = db.Column(db.Text, nullable=False)
    proof = db.Column(db.Integer, nullable=False)
    previous_hash = db.Column(db.String(64), nullable=False)

    def __repr__(self):
        return f'<Block {self.index}>'

# Create database tables
try:
    with app.app_context():
        db.create_all()
        print("Database tables created successfully!")
except Exception as e:
    print(f"Error creating database tables: {e}")
    # Try to create the database directory if it doesn't exist
    os.makedirs(os.path.dirname('instance/'), exist_ok=True)
    try:
        with app.app_context():
            db.create_all()
            print("Database tables created successfully on second attempt!")
    except Exception as e2:
        print(f"Failed to create database tables: {e2}")

# Blockchain Implementation
class Blockchain:
    def __init__(self):
        self.chain = []
        self.current_transactions = []
        self.load_chain_from_db()
        
        # Create genesis block if chain is empty
        if len(self.chain) == 0:
            print("Creating genesis block...")
            self.new_block(previous_hash='1', proof=100)

    def load_chain_from_db(self):
        try:
            with app.app_context():
                blocks = Block.query.order_by(Block.index).all()
                for block in blocks:
                    self.chain.append({
                        'index': block.index,
                        'timestamp': block.timestamp.timestamp(),
                        'transactions': json.loads(block.transactions),
                        'proof': block.proof,
                        'previous_hash': block.previous_hash
                    })
                print(f"Loaded {len(blocks)} blocks from database")
        except Exception as e:
            print(f"Error loading chain from database: {e}")
            # If there's an error, start with an empty chain
            self.chain = []

    def new_block(self, proof, previous_hash=None):
        block = {
            'index': len(self.chain) + 1,
            'timestamp': time.time(),
            'transactions': self.current_transactions.copy(),  # Use copy to avoid reference issues
            'proof': proof,
            'previous_hash': previous_hash or self.hash(self.chain[-1]) if self.chain else '1',
        }
        
        # Save to database
        try:
            with app.app_context():
                db_block = Block(
                    index=block['index'],
                    timestamp=datetime.fromtimestamp(block['timestamp']),
                    transactions=json.dumps(block['transactions']),
                    proof=block['proof'],
                    previous_hash=block['previous_hash']
                )
                db.session.add(db_block)
                db.session.commit()
                print(f"Block {block['index']} saved to database")
        except Exception as e:
            print(f"Error saving block to database: {e}")
            # Continue even if database save fails
            pass
        
        self.current_transactions = []
        self.chain.append(block)
        return block

    def new_transaction(self, product_id, action, actor_id, details):
        transaction = {
            'product_id': product_id,
            'action': action,
            'actor_id': actor_id,
            'details': details,
            'timestamp': time.time()
        }
        
        # Save to database
        try:
            with app.app_context():
                db_transaction = Transaction(
                    product_id=product_id,
                    action=action,
                    actor_id=actor_id,
                    details=json.dumps(details),
                    timestamp=datetime.fromtimestamp(time.time())
                )
                db.session.add(db_transaction)
                db.session.commit()
                print(f"Transaction saved to database: {action} for {product_id}")
        except Exception as e:
            print(f"Error saving transaction to database: {e}")
            # Continue even if database save fails
            pass
        
        self.current_transactions.append(transaction)
        return self.last_block['index'] + 1 if self.chain else 1

    @property
    def last_block(self):
        return self.chain[-1] if self.chain else None

    @staticmethod
    def hash(block):
        block_string = json.dumps(block, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()

    def proof_of_work(self, last_proof):
        proof = 0
        while not self.valid_proof(last_proof, proof):
            proof += 1
        return proof

    @staticmethod
    def valid_proof(last_proof, proof):
        guess = f"{last_proof}{proof}".encode()
        return hashlib.sha256(guess).hexdigest()[:4] == '0000'

# Initialize blockchain
blockchain = Blockchain()

# Helper functions
def get_current_user():
    if 'user_id' in session:
        try:
            with app.app_context():
                return User.query.get(session['user_id'])
        except Exception as e:
            print(f"Error getting current user: {e}")
            return None
    return None

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            # Check if email already exists
            with app.app_context():
                existing_user = User.query.filter_by(email=request.form['email']).first()
                if existing_user:
                    flash('Email already registered. Please use a different email.', 'danger')
                    return redirect(url_for('register'))
            
            # Generate user details
            user_id = str(uuid.uuid4())[:8]
            name = request.form['name']
            email = request.form['email']
            role = request.form['role']
            password_hash = hashlib.sha256(request.form['password'].encode()).hexdigest()
            wallet_address = hashlib.sha256(f"{name}{role}{time.time()}".encode()).hexdigest()[:16]
            
            # Create new user
            with app.app_context():
                user = User(
                    id=user_id,
                    name=name,
                    email=email,
                    role=role,
                    wallet_address=wallet_address,
                    password_hash=password_hash
                )
                db.session.add(user)
                db.session.commit()
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            flash(f'Error during registration: {str(e)}', 'danger')
            # Log the full error for debugging
            app.logger.error(f"Registration error: {str(e)}")
            return redirect(url_for('register'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password_hash = hashlib.sha256(request.form['password'].encode()).hexdigest()
        
        try:
            with app.app_context():
                user = User.query.filter_by(email=email, password_hash=password_hash).first()
            
            if user:
                session['user_id'] = user.id
                flash('Login successful!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid email or password. Please try again.', 'danger')
        except Exception as e:
            flash(f'Error during login: {str(e)}', 'danger')
    
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))
    
    try:
        with app.app_context():
            user_products = Product.query.filter_by(current_owner_id=user.id).all() if user.role == 'farmer' else []
            all_products = Product.query.all() if user.role == 'admin' else []
            all_users = User.query.all() if user.role == 'admin' else []
        
        return render_template('dashboard.html', user=user, products=user_products, 
                              all_products=all_products, all_users=all_users)
    except Exception as e:
        flash(f'Error loading dashboard: {str(e)}', 'danger')
        return redirect(url_for('index'))

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    user = get_current_user()
    if not user or user.role != 'farmer':
        flash('Access denied. Only farmers can add products.', 'danger')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        try:
            product_id = str(uuid.uuid4())[:8]
            name = request.form['name']
            origin = request.form['origin']
            harvest_date = request.form['harvest_date']
            initial_price = float(request.form['initial_price'])
            quality_metrics = request.form['quality_metrics']
            
            with app.app_context():
                # Create new product
                product = Product(
                    id=product_id,
                    name=name,
                    origin=origin,
                    harvest_date=harvest_date,
                    initial_price=initial_price,
                    quality_metrics=quality_metrics,
                    current_owner_id=user.id
                )
                db.session.add(product)
                db.session.commit()
            
            # Add initial transaction to blockchain
            details = {
                'action': 'harvest',
                'origin': origin,
                'harvest_date': harvest_date,
                'initial_price': initial_price,
                'quality_metrics': quality_metrics
            }
            blockchain.new_transaction(product_id, 'harvest', user.id, details)
            
            # Mine a new block
            if blockchain.last_block:
                proof = blockchain.proof_of_work(blockchain.last_block['proof'])
                blockchain.new_block(proof)
            
            flash('Product added successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error adding product: {str(e)}', 'danger')
    
    return render_template('add_product.html', user=user)

@app.route('/transfer_product', methods=['GET', 'POST'])
def transfer_product():
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        try:
            product_id = request.form['product_id']
            to_user_id = request.form['to_user_id']
            price = float(request.form['price'])
            quality_check = request.form['quality_check']
            
            with app.app_context():
                product = Product.query.get(product_id)
                if not product:
                    flash('Product not found', 'danger')
                    return redirect(url_for('dashboard'))
                
                to_user = User.query.get(to_user_id)
                if not to_user:
                    flash('Recipient user not found', 'danger')
                    return redirect(url_for('dashboard'))
                
                # Update product ownership
                product.current_owner_id = to_user_id
                db.session.commit()
            
            # Add transfer transaction to blockchain
            details = {
                'from': user.id,
                'to': to_user_id,
                'price': price,
                'quality_check': quality_check
            }
            blockchain.new_transaction(product_id, 'transfer', user.id, details)
            
            # Mine a new block
            if blockchain.last_block:
                proof = blockchain.proof_of_work(blockchain.last_block['proof'])
                blockchain.new_block(proof)
            
            flash('Product transferred successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error transferring product: {str(e)}', 'danger')
    
    try:
        with app.app_context():
            products = Product.query.all()
            users = User.query.all()
        
        return render_template('transfer_product.html', user=user, products=products, users=users)
    except Exception as e:
        flash(f'Error loading transfer page: {str(e)}', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/product_history/<product_id>')
def product_history(product_id):
    try:
        with app.app_context():
            product = Product.query.get(product_id)
            if not product:
                flash('Product not found', 'danger')
                return redirect(url_for('dashboard'))
            
            # Eager load the actor relationship to avoid session issues
            history = Transaction.query.options(db.joinedload(Transaction.actor)).filter_by(product_id=product_id).order_by(Transaction.timestamp).all()
        
        return render_template('product_history.html', 
                              product=product, 
                              product_history=history)
    except Exception as e:
        flash(f'Error loading product history: {str(e)}', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/verify_product/<product_id>')
def verify_product(product_id):
    try:
        with app.app_context():
            product = Product.query.get(product_id)
            if not product:
                flash('Product not found', 'danger')
                return redirect(url_for('dashboard'))
            
            # Eager load the actor relationship
            db_history = Transaction.query.options(db.joinedload(Transaction.actor)).filter_by(product_id=product_id).order_by(Transaction.timestamp).all()
        
        # Get history from blockchain
        blockchain_history = []
        for block in blockchain.chain:
            for transaction in block['transactions']:
                if transaction['product_id'] == product_id:
                    blockchain_history.append(transaction)
        
        # Verify consistency
        is_valid = True
        discrepancies = []
        
        if len(db_history) != len(blockchain_history):
            is_valid = False
            discrepancies.append(f"History length mismatch: DB has {len(db_history)}, blockchain has {len(blockchain_history)} records")
        else:
            for i, (db_record, bc_record) in enumerate(zip(db_history, blockchain_history)):
                db_details = json.loads(db_record.details)
                if (db_record.action != bc_record['action'] or 
                    db_record.actor_id != bc_record['actor_id'] or
                    db_details != bc_record['details']):
                    is_valid = False
                    discrepancies.append(f"Record {i} doesn't match between DB and blockchain")
        
        return render_template('verify_product.html', 
                              product=product, 
                              is_valid=is_valid,
                              discrepancies=discrepancies,
                              db_history=db_history,
                              blockchain_history=blockchain_history)
    except Exception as e:
        flash(f'Error verifying product: {str(e)}', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/api/blockchain')
def get_blockchain():
    return jsonify(blockchain.chain)

@app.route('/api/product/<product_id>')
def get_product_api(product_id):
    try:
        with app.app_context():
            product = Product.query.get(product_id)
            if not product:
                return jsonify({"error": "Product not found"}), 404
            
            # Eager load the actor relationship
            history = Transaction.query.options(db.joinedload(Transaction.actor)).filter_by(product_id=product_id).order_by(Transaction.timestamp).all()
        
        return jsonify({
            'product_id': product.id,
            'name': product.name,
            'farmer_id': product.current_owner_id,
            'origin': product.origin,
            'harvest_date': product.harvest_date,
            'initial_price': product.initial_price,
            'quality_metrics': product.quality_metrics,
            'current_owner': product.current_owner_id,
            'history': [{
                'action': t.action,
                'actor_id': t.actor_id,
                'actor_name': t.actor.name if t.actor else 'Unknown',
                'details': json.loads(t.details),
                'timestamp': t.timestamp.timestamp()
            } for t in history]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/test_db')
def test_db():
    try:
        with app.app_context():
            user_count = User.query.count()
            return f"Database connection successful! Users in database: {user_count}"
    except Exception as e:
        return f"Database connection failed: {str(e)}"

if __name__ == '__main__':
    # Make sure database tables are created
    try:
        with app.app_context():
            db.create_all()
            print("Database tables created successfully!")
    except Exception as e:
        print(f"Error creating database tables: {e}")
    
    app.run(debug=True, host='0.0.0.0', port=5000)